import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {CategoriesComponent} from './categories/categories.component';
import {CategoryDashboardComponent} from './category-dashboard/category-dashboard.component';
import {CategoryDetailComponent} from './category-detail/category-detail.component';
import {AddBookComponent} from './add-book/add-book.component';
import {AddBookResultComponent} from './add-book-result/add-book-result.component';
import {RegistrationComponent} from './registration/registration.component';
import {LoginComponent} from './login/login.component';
import {RegistrationResultComponent} from './registration-result/registration-result.component';

const routes: Routes = [
  { path: '', redirectTo: '/category-dashboard', pathMatch: 'full' },
  {path: 'categories' , component: CategoriesComponent},
  {path: 'category-dashboard' , component: CategoryDashboardComponent},
  { path: 'category/:id', component: CategoryDetailComponent },
  { path: 'addBooks', component: AddBookComponent },
  { path: 'addBookResult', component: AddBookResultComponent },
  { path: 'registration', component: RegistrationComponent },
  { path: 'login', component: LoginComponent },
  { path: 'registrationSuccess', component: RegistrationResultComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
