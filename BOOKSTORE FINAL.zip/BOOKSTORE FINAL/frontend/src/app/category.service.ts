import { Injectable } from '@angular/core';
import {Category} from './category';
import {CATEGORIES} from './mock-categories';
import {Observable, of} from 'rxjs';
import {MessageService} from './message.service';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {catchError, tap} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class CategoryService {

  public httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };

  private getAllCategoriesUrl = 'http://localhost:5800/getAllCategoryDetails';
  private getCategoryDetails = 'http://localhost:5800/getCategoryDetails';
  private updateCategoryDetails = 'http://localhost:5800/newCategory';
  private saveCategoryDetails = 'http://localhost:5800/newCategory';
  private deleteCategoryDetails = 'http://localhost:5800/deleteCategory';

  constructor(
    private http: HttpClient,
    private messageService: MessageService) { }
  getCategories(): Observable<Category[]> {
    return this.http.get<Category[]>(this.getAllCategoriesUrl);
  }
  getCategory(id: number): Observable<Category> {
    const url = `${this.getCategoryDetails}/${id}`;
    return this.http.get<Category>(url);
  }
  updateCategory(category: Category): Observable<any> {
    return this.http.post(this.updateCategoryDetails, category, this.httpOptions);
  }
  deleteCategory(category: Category | number): Observable<Category> {
    const id = typeof category === 'number' ? category : category.categoryId;
    const url = `${this.deleteCategoryDetails}/${id}`;
    return this.http.delete<Category>(url, this.httpOptions);
  }

  public addCategory(category: Category) {
    return this.http.post<Category>(this.saveCategoryDetails, category);
  }
}
