export class Book {
  bookId: number;
  title: string;
  price: number;
  publishYear: number;
  publisher: string;
  summaryDetails: string;
  rating: number;
  authorId: number;
}
