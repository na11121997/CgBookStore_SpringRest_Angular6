import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {Observable, of} from 'rxjs';
import {Book} from './Book';

@Injectable({
  providedIn: 'root'
})
export class BookstoreService {
  public httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };
  private Url: string;
  private deleteBookDetails = 'http://localhost:5800/deleteBooks';

  constructor(private http: HttpClient) {
    this.Url = 'http://localhost:5800/newBooks';
  }
  public save(book: Book) {
    return this.http.post<Book>(this.Url, book);
  }
  public findAll(): Observable<any> {
    return this.http.get('http://localhost:5800/getAllBooksDetails');
  }
  deleteBooks(book: Book | number) {
    const id = typeof book === 'number' ? book : book.bookId;
    const url = `${this.deleteBookDetails}/${id}`;
    console.log(url);
    return this.http.delete<Book>(url, this.httpOptions);
  }

}
