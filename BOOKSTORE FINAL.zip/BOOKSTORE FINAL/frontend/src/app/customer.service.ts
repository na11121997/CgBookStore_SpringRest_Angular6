import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {Customer} from './Customer';
import {Book} from './Book';
import {Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  public httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };
  private Url: string;
  private deleteCustomerDetails = 'http://localhost:5800/deleteCustomer';
  constructor(private http: HttpClient) {
    this.Url = 'http://localhost:5800/newCustomer';
  }

  public save(customer: Customer) {
    return this.http.post<Customer>(this.Url, customer);
  }
  public findAll(): Observable<any> {
    return this.http.get('http://localhost:5800/getAllCustomerDetails');

  }
  deleteBooks(customer: Customer | number) {
    const id = typeof customer === 'number' ? customer : customer.customerId;
    const url = `${this.deleteCustomerDetails}/${id}`;
    return this.http.delete<Customer>(url, this.httpOptions);
  }

}
