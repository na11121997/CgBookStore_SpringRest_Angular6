import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CategoriesComponent } from './categories/categories.component';
import {FormsModule} from '@angular/forms';
import { CategoryDetailComponent } from './category-detail/category-detail.component';
import { MessagesComponent } from './messages/messages.component';
import { CategoryDashboardComponent } from './category-dashboard/category-dashboard.component';
import {HttpClientModule} from '@angular/common/http';
import { AddBookComponent } from './add-book/add-book.component';
import { AddBookResultComponent } from './add-book-result/add-book-result.component';
import { RegistrationComponent } from './registration/registration.component';
import { LoginComponent } from './login/login.component';
import { RegistrationResultComponent } from './registration-result/registration-result.component';

@NgModule({
  declarations: [
    AppComponent,
    CategoriesComponent,
    CategoryDetailComponent,
    MessagesComponent,
    CategoryDashboardComponent,
    AddBookComponent,
    AddBookResultComponent,
    RegistrationComponent,
    LoginComponent,
    RegistrationResultComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
