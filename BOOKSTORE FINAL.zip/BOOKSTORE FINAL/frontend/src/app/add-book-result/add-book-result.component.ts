import { Component, OnInit } from '@angular/core';
import {BookstoreService} from '../bookstore.service';
import {Book} from '../Book';

@Component({
  selector: 'app-add-book-result',
  templateUrl: './add-book-result.component.html',
  styleUrls: ['./add-book-result.component.css']
})
export class AddBookResultComponent implements OnInit {
  books: Array<any>;
  book: Book;
  constructor(private bookServices: BookstoreService) {
  }

  ngOnInit() {
    this.bookServices.findAll().subscribe(data => {
      this.books = data;
    });
  }
  delete(book: Book): void {
    this.books = this.books.filter(c => c !== book);
    this.bookServices.deleteBooks(book).subscribe();
  }
}
