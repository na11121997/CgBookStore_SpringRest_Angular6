export class  Customer {
  customerId: number;
  customerFirstName: string;
  customerLastName: string;
  email: string;
  phoneNumber: string;
  password: string;
}
