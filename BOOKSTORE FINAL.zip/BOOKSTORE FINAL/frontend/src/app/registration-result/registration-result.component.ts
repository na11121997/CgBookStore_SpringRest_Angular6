import { Component, OnInit } from '@angular/core';
import {Customer} from '../Customer';
import {CustomerService} from '../customer.service';
import {Book} from '../Book';

@Component({
  selector: 'app-registration-result',
  templateUrl: './registration-result.component.html',
  styleUrls: ['./registration-result.component.css']
})
export class RegistrationResultComponent implements OnInit {
  customers: Array<any>;
  customer: Customer;
  constructor(private customerServices: CustomerService) {
  }
  ngOnInit() {
    this.customerServices.findAll().subscribe(data => {
      this.customers = data;
    });
  }
  delete(customer: Customer): void {
    this.customers = this.customers.filter(c => c !== customer);
    this.customerServices.deleteBooks(customer).subscribe();
  }
}
