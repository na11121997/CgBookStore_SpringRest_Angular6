import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddBookResultComponent } from './add-book-result.component';

describe('AddBookResultComponent', () => {
  let component: AddBookResultComponent;
  let fixture: ComponentFixture<AddBookResultComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddBookResultComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddBookResultComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
