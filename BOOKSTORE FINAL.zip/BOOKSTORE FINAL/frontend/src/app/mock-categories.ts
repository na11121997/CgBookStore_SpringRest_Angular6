import {Category} from './category';


export const CATEGORIES: Category[] = [
  { categoryId: 1, categoryName: 'Thriller' },
  { categoryId: 2, categoryName: 'Comedy' },
  { categoryId: 3, categoryName: 'Romantic' },
  { categoryId: 4, categoryName: 'Horror' },
  { categoryId: 5, categoryName: 'Drama' },
  { categoryId: 6, categoryName: 'Poems' },
  { categoryId: 7, categoryName: 'Songs' },
  { categoryId: 8, categoryName: 'Classic Literature' }
];
