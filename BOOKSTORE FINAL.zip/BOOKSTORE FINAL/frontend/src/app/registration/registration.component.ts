import { Component, OnInit } from '@angular/core';
import {Customer} from '../Customer';
import {ActivatedRoute, Router} from '@angular/router';
import {CustomerService} from '../customer.service';


@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  customer: Customer;

  ngOnInit() {
  }
  constructor(private route: ActivatedRoute, private router: Router, private customerService: CustomerService){
    this.customer = new Customer();
  }
  onSubmit() {
    this.customerService.save(this.customer).subscribe(result => console.log('b'));
  }
  gotoUserList() {
    console.log('b');
    this.router.navigate(['/registrationSuccess']);
  }
}
