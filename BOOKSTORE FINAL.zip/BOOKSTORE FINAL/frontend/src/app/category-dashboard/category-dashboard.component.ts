import { Component, OnInit } from '@angular/core';
import {Category} from '../category';
import {CategoryService} from '../category.service';
import {BookstoreService} from '../bookstore.service';
import {Book} from '../Book';

@Component({
  selector: 'app-category-dashboard',
  templateUrl: './category-dashboard.component.html',
  styleUrls: ['./category-dashboard.component.css']
})
export class CategoryDashboardComponent implements OnInit {

  constructor(private categoryService: CategoryService, private bookStoreService: BookstoreService) { }


  categories: Category[] = [];
  books: Book[] = [];
  ngOnInit() {
    this.getCategories();
    this.getBooks();
  }

  getCategories(): void {
    this.categoryService.getCategories().subscribe(
      categories => this.categories = categories.slice(1, 5));

  }
  getBooks(): void {
    this.bookStoreService.findAll().subscribe(
      books => this.books = books.slice(0, 2));

  }
}
